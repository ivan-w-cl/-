# Lesson 06 · combined entry (integration bundle)

Open `index.html`. It hosts one section player at a time (`players/L06S0n_player_standalone.html`). Switching sections removes
the previous player completely (its clock, listeners and any later audio), then opens the new section at its start.

- Mode (Watch / Practice) in the top bar is forwarded to the live section; section controls (play, restart, seek, captions,
  reduced motion, speed 1 / 1.25 / 1.5 / 2) are in each player.
- A section never advances by itself; at its end the player offers an explicit Next section action.
- chapters.json: chapter order, compiled Watch durations, Watch start offsets for a concatenated export, Practice route lengths.

## Assembly into another site (not done here; no website was edited)
1. Copy `index.html`, `chapters.json` and `players/` together; keep the relative paths.
2. Or link each `players/L06S0n_player_standalone.html` directly; each is self-contained (inline CSS, JS and data; no remote requests).
3. Per-section source and playable ZIPs are delivered separately (`esssouth-L06S0n-source.zip`, `-playable.zip`).

All seven sections are present in this bundle. Status per section: see BUILD_STATUS.json.
