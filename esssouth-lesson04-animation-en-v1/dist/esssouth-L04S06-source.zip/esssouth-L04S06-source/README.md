# esssouth · Lesson 04 · 4.6 Rehearse a Constructive Disagreement · silent English review

Status: **verified** (from BUILD_STATUS.json). QA: qa/S06/report.json (2026-10-29T22:30:16.007Z, Chromium 153.0.8010.12, 66 checks, 0 failed).

## Open
- `sections/S06/L04S06_player_standalone.html`: self-contained offline player (open from disk; no server, no network).
- `sections/S06/index.html`: the same player from editable source (`../../shared/`, `data/`, `scenes.js`).
- URL options: `?mode=practice`, `?t=<s>`, `?rm=1`, `?nocap=1`, `?rate=1.5`, `?timing=retime-demo`, `?text=x1.3|x1.6|long`, `?debug=slots`, `?export=1`.

## Built duration (silent, estimated timing)
- Watch: **310.966 s**.
- Practice: `practice:model` 277.166 s, `practice:skip` 228.972 s; waiting at the gate is unlimited and not counted.
- Interaction L04.I03 (private_rehearsal): Watch shows its thinking time and one declared path; Practice waits for a choice, Try again, Skip or Continue.

## Edit and rebuild (Node 18+)
- Words, labels, anchors, timing and audio slots: `sections/S06/content/source/` (exact inputs; keep unchanged unless the script changes), diagram labels `content/labels.staging.en.json`, staging anchors `content/staging-anchors.json`, choreography `scenes.js`.
- `node tools/build.mjs S06`: validate, then write `data/`, `index.html` and the standalone player.
- QA (Playwright + Chromium): `NODE_PATH=<dir containing playwright> node tools/qa.cjs S06`. Results: `qa/S06/report.json`, `TEST_REPORT.md`.
- Docs: `node tools/docs.cjs S06` (STORYBOARD.md, SCENE_MAP.json, TEST_REPORT.md).
- Future audio: `node tools/attach-audio.mjs S06 mapping.json [--dry-run]`, then `node tools/build.mjs S06 --audio=<lang>` (see shared/l04/audio-hook.js).
- Silent MP4 + SRT: `node tools/export-mp4.cjs S06` (needs ffmpeg).

See STORYBOARD.md (scene map with stills), TEST_REPORT.md (actual results and what was not tested), CHANGES_FROM_HANDOFF.md and STYLE_PROVENANCE.md.
