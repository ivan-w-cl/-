# esssouth · Lesson 04 · 4.5 Revise a Proposal Without Inventing Agreement · silent English review

Status: **packaged** (from BUILD_STATUS.json). QA: qa/S05/report.json (2026-10-29T22:29:39.431Z, Chromium 153.0.8010.12, 39 checks, 0 failed).

## Open
- `sections/S05/L04S05_player_standalone.html`: self-contained offline player (open from disk; no server, no network).
- `sections/S05/index.html`: the same player from editable source (`../../shared/`, `data/`, `scenes.js`).
- URL options: `?mode=practice`, `?t=<s>`, `?rm=1`, `?nocap=1`, `?rate=1.5`, `?timing=retime-demo`, `?text=x1.3|x1.6|long`, `?debug=slots`, `?export=1`.

## Built duration (silent, estimated timing)
- Watch: **230.536 s**.
- Practice: `practice:main` 230.536 s; waiting at the gate is unlimited and not counted.
- No interaction gate: Watch and Practice share the same route and holds.

## Edit and rebuild (Node 18+)
- Words, labels, anchors, timing and audio slots: `sections/S05/content/source/` (exact inputs; keep unchanged unless the script changes), diagram labels `content/labels.staging.en.json`, staging anchors `content/staging-anchors.json`, choreography `scenes.js`.
- `node tools/build.mjs S05`: validate, then write `data/`, `index.html` and the standalone player.
- QA (Playwright + Chromium): `NODE_PATH=<dir containing playwright> node tools/qa.cjs S05`. Results: `qa/S05/report.json`, `TEST_REPORT.md`.
- Docs: `node tools/docs.cjs S05` (STORYBOARD.md, SCENE_MAP.json, TEST_REPORT.md).
- Future audio: `node tools/attach-audio.mjs S05 mapping.json [--dry-run]`, then `node tools/build.mjs S05 --audio=<lang>` (see shared/l04/audio-hook.js).
- Silent MP4 + SRT: `node tools/export-mp4.cjs S05` (needs ffmpeg).

See STORYBOARD.md (scene map with stills), TEST_REPORT.md (actual results and what was not tested), CHANGES_FROM_HANDOFF.md and STYLE_PROVENANCE.md.
