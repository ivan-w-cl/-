# 8.2 Separate Shared Ground from Open Questions · playable silent review

Open `L08S02_player_standalone.html` in a current desktop browser (from disk; no server or network needed).
Watch 291.248 s · interaction L08.I01. Add `?mode=practice` for Practice.
The Next section button needs the next section's standalone player beside this file (the lesson bundle has all seven).
Silent: no narration, music or test tones. Nothing is recorded or stored. Tested in Chromium only (see TEST_REPORT.md).
