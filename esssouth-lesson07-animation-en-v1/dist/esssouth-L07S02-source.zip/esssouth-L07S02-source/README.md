# esssouth · Lesson 07 · 7.2 Restart After a Pause · silent English review

Status: **verified** (from BUILD_STATUS.json). QA: qa/S02/report.json (2026-10-30T04:00:20.184Z, Chromium 153.0.8010.12, 99 checks, 0 failed).

## Open
- `sections/S02/L07S02_player_standalone.html`: self-contained offline player (open from disk; no server, no network).
- `sections/S02/index.html`: the same player from editable source (`../../shared/`, `data/`, `scenes.js`).
- URL options: `?mode=practice`, `?t=<s>`, `?rm=1`, `?nocap=1`, `?rate=1.5`, `?timing=retime-demo`, `?text=x1.3|x1.6|long`, `?debug=slots`, `?export=1`.

## Built duration (silent, estimated timing)
- Watch: **247.459 s**.
- Practice: `practice:A` 233.802 s, `practice:B` 240.659 s, `practice:C` 234.659 s, `practice:skip` 208.752 s; waiting at the gate is unlimited and not counted.
- Interaction L07.I01 (choice): Watch shows its thinking time and one declared path; Practice waits for a choice, Try again, Skip or Continue.

## Edit and rebuild (Node 18+)
- Words, labels, anchors, timing and audio slots: `sections/S02/content/source/` (exact inputs; keep unchanged unless the script changes), diagram labels `content/labels.staging.en.json`, staging anchors `content/staging-anchors.json`, choreography `scenes.js`.
- `node tools/build.mjs S02`: validate, then write `data/`, `index.html` and the standalone player.
- QA (Playwright + Chromium): `NODE_PATH=<dir containing playwright> node tools/qa.cjs S02`. Results: `qa/S02/report.json`, `TEST_REPORT.md`.
- Docs: `node tools/docs.cjs S02` (STORYBOARD.md, SCENE_MAP.json, TEST_REPORT.md).
- Future audio: `node tools/attach-audio.mjs S02 mapping.json [--dry-run]`, then `node tools/build.mjs S02 --audio=<lang>` (see shared/l07/audio-hook.js).
- Silent MP4 + SRT: `node tools/export-mp4.cjs S02` (needs ffmpeg).

See STORYBOARD.md (scene map with stills), TEST_REPORT.md (actual results and what was not tested), CHANGES_FROM_HANDOFF.md and STYLE_PROVENANCE.md.
