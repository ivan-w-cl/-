# esssouth · Lesson 08 · 8.4 Explain a Trade-off against Shared Criteria · silent English review

Status: **packaged** (from BUILD_STATUS.json). QA: qa/S04/report.json (2026-10-30T06:52:04.947Z, Chromium 153.0.8010.12, 44 checks, 0 failed).

## Open
- `sections/S04/L08S04_player_standalone.html`: self-contained offline player (open from disk; no server, no network).
- `sections/S04/index.html`: the same player from editable source (`../../shared/`, `data/`, `scenes.js`).
- URL options: `?mode=practice`, `?t=<s>`, `?rm=1`, `?nocap=1`, `?rate=1.5`, `?timing=retime-demo`, `?text=x1.3|x1.6|long`, `?debug=slots`, `?export=1`.

## Built duration (silent, estimated timing)
- Watch: **276.12 s**.
- Practice: `practice:main` 276.12 s; waiting at the gate is unlimited and not counted.
- No interaction gate: Watch and Practice share the same route and holds.

## Edit and rebuild (Node 18+)
- Words, labels, anchors, timing and audio slots: `sections/S04/content/source/` (exact inputs; keep unchanged unless the script changes), diagram labels `content/labels.staging.en.json`, staging anchors `content/staging-anchors.json`, choreography `scenes.js`.
- `node tools/build.mjs S04`: validate, then write `data/`, `index.html` and the standalone player.
- QA (Playwright + Chromium): `NODE_PATH=<dir containing playwright> node tools/qa.cjs S04`. Results: `qa/S04/report.json`, `TEST_REPORT.md`.
- Docs: `node tools/docs.cjs S04` (STORYBOARD.md, SCENE_MAP.json, TEST_REPORT.md).
- Future audio: `node tools/attach-audio.mjs S04 mapping.json [--dry-run]`, then `node tools/build.mjs S04 --audio=<lang>` (see shared/l08/audio-hook.js).
- Silent MP4 + SRT: `node tools/export-mp4.cjs S04` (needs ffmpeg).

See STORYBOARD.md (scene map with stills), TEST_REPORT.md (actual results and what was not tested), CHANGES_FROM_HANDOFF.md and STYLE_PROVENANCE.md.
