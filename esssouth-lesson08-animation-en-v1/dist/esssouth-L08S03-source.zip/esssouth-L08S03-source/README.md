# esssouth · Lesson 08 · 8.3 Combine Compatible Contributions · silent English review

Status: **packaged** (from BUILD_STATUS.json). QA: qa/S03/report.json (2026-10-30T06:51:15.723Z, Chromium 153.0.8010.12, 95 checks, 0 failed).

## Open
- `sections/S03/L08S03_player_standalone.html`: self-contained offline player (open from disk; no server, no network).
- `sections/S03/index.html`: the same player from editable source (`../../shared/`, `data/`, `scenes.js`).
- URL options: `?mode=practice`, `?t=<s>`, `?rm=1`, `?nocap=1`, `?rate=1.5`, `?timing=retime-demo`, `?text=x1.3|x1.6|long`, `?debug=slots`, `?export=1`.

## Built duration (silent, estimated timing)
- Watch: **308.823 s**.
- Practice: `practice:A` 290.879 s, `practice:B` 295.594 s, `practice:C` 302.023 s, `practice:skip` 260.258 s; waiting at the gate is unlimited and not counted.
- Interaction L08.I02 (choice): Watch shows its thinking time and one declared path; Practice waits for a choice, Try again, Skip or Continue.

## Edit and rebuild (Node 18+)
- Words, labels, anchors, timing and audio slots: `sections/S03/content/source/` (exact inputs; keep unchanged unless the script changes), diagram labels `content/labels.staging.en.json`, staging anchors `content/staging-anchors.json`, choreography `scenes.js`.
- `node tools/build.mjs S03`: validate, then write `data/`, `index.html` and the standalone player.
- QA (Playwright + Chromium): `NODE_PATH=<dir containing playwright> node tools/qa.cjs S03`. Results: `qa/S03/report.json`, `TEST_REPORT.md`.
- Docs: `node tools/docs.cjs S03` (STORYBOARD.md, SCENE_MAP.json, TEST_REPORT.md).
- Future audio: `node tools/attach-audio.mjs S03 mapping.json [--dry-run]`, then `node tools/build.mjs S03 --audio=<lang>` (see shared/l08/audio-hook.js).
- Silent MP4 + SRT: `node tools/export-mp4.cjs S03` (needs ffmpeg).

See STORYBOARD.md (scene map with stills), TEST_REPORT.md (actual results and what was not tested), CHANGES_FROM_HANDOFF.md and STYLE_PROVENANCE.md.
