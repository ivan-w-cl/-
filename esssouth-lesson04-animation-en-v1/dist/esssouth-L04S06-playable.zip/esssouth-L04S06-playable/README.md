# 4.6 Rehearse a Constructive Disagreement · playable silent review

Open `L04S06_player_standalone.html` in a current desktop browser (from disk; no server or network needed).
Watch 310.966 s · interaction L04.I03. Add `?mode=practice` for Practice.
The Next section button needs the next section's standalone player beside this file (the lesson bundle has all seven).
Silent: no narration, music or test tones. Nothing is recorded or stored. Tested in Chromium only (see TEST_REPORT.md).
