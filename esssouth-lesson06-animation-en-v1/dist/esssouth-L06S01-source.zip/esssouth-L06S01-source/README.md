# esssouth · Lesson 06 · 6.1 Choose One Specific Experience · silent English review

Status: **packaged** (from BUILD_STATUS.json). QA: qa/S01/report.json (2026-10-30T00:16:28.791Z, Chromium 153.0.8010.12, 41 checks, 0 failed).

## Open
- `sections/S01/L06S01_player_standalone.html`: self-contained offline player (open from disk; no server, no network).
- `sections/S01/index.html`: the same player from editable source (`../../shared/`, `data/`, `scenes.js`).
- URL options: `?mode=practice`, `?t=<s>`, `?rm=1`, `?nocap=1`, `?rate=1.5`, `?timing=retime-demo`, `?text=x1.3|x1.6|long`, `?debug=slots`, `?export=1`.

## Built duration (silent, estimated timing)
- Watch: **236.902 s**.
- Practice: `practice:main` 236.902 s; waiting at the gate is unlimited and not counted.
- No interaction gate: Watch and Practice share the same route and holds.

## Edit and rebuild (Node 18+)
- Words, labels, anchors, timing and audio slots: `sections/S01/content/source/` (exact inputs; keep unchanged unless the script changes), diagram labels `content/labels.staging.en.json`, staging anchors `content/staging-anchors.json`, choreography `scenes.js`.
- `node tools/build.mjs S01`: validate, then write `data/`, `index.html` and the standalone player.
- QA (Playwright + Chromium): `NODE_PATH=<dir containing playwright> node tools/qa.cjs S01`. Results: `qa/S01/report.json`, `TEST_REPORT.md`.
- Docs: `node tools/docs.cjs S01` (STORYBOARD.md, SCENE_MAP.json, TEST_REPORT.md).
- Future audio: `node tools/attach-audio.mjs S01 mapping.json [--dry-run]`, then `node tools/build.mjs S01 --audio=<lang>` (see shared/l06/audio-hook.js).
- Silent MP4 + SRT: `node tools/export-mp4.cjs S01` (needs ffmpeg).

See STORYBOARD.md (scene map with stills), TEST_REPORT.md (actual results and what was not tested), CHANGES_FROM_HANDOFF.md and STYLE_PROVENANCE.md.
