# 6.2 Make Your Own Contribution Clear · playable silent review

Open `L06S02_player_standalone.html` in a current desktop browser (from disk; no server or network needed).
Watch 259.741 s · interaction L06.I01. Add `?mode=practice` for Practice.
The Next section button needs the next section's standalone player beside this file (the lesson bundle has all seven).
Silent: no narration, music or test tones. Nothing is recorded or stored. Tested in Chromium only (see TEST_REPORT.md).
