# 案件档案 · 英文版（Case File）打包

| 文件夹 | 内容 |
|---|---|
| `视频/` | 成片两版：`-music.mp4`（配音 + 音乐）、`-no-music.mp4`（只有配音），以及英文字幕 `.srt`。1080×1920，约 2 分 03 秒 |
| `文字稿/` | `英文版文字稿（中英对照）.md`：逐句时间、内容类型、依据和中文对照；`English-script.txt`：纯英文旁白；字幕 `.srt` |
| `项目源码/` | 完整 Remotion 工程（不含 node_modules）：文案、配音 WAV、产品截图、字体、背景音乐、渲染脚本、在线页。说明见其中的 `README.md` |
| `skill/esssouth-casefile-video/` | 制作这类"案件档案"视频的 skill：`SKILL.md`，以及 `references/` 里的 esssouth 通用制作标准 |

## 重新渲染
```
cd 项目源码
npm install
node tools/render.mjs stills   # 检查图
node tools/render.mjs          # 两个 MP4 + SRT
```

## 使用 skill
把 `skill/esssouth-casefile-video/` 整个文件夹复制到项目的 `.claude/skills/`（或个人的 `~/.claude/skills/`）下。之后让 Claude"按案件档案的形式做一支新的升学科普视频"即可。

依据为西交利物浦大学、香港中文大学（深圳）2026 年江苏、广东综合评价招生简章，于 2026-11-18 核对。算例是假设，不预测录取。esssouth 与学校无官方合作关系。
